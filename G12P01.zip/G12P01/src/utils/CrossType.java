package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum CrossType {
	Monopoint, Uniform, BLX, Arithmetic
}
