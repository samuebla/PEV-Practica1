package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum FunctionType {
	f1,f2_Schubert, f3_EggHolder, f4_Michalewicz 
}
