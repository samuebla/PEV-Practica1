package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum SelectionType {
	Roulette, RandomTournament, DetTournament, Remains, Truncation, Stochastic
}
