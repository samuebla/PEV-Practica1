package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum MutationType {
	Basic, Basic_Double
}
