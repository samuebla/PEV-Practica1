package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum FunctionType {
	fP2 
}
