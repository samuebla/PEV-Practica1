package utilsFlight;

import java.util.List;

import utilsFlight.FlightType;

public class TVuelo {
	public String name_;
	public List<Double> TTEL_vuelo;
	public FlightType type_;
	
	public TVuelo() {
	}

}
