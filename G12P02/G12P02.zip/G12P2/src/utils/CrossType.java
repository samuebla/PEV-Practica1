package utils;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum CrossType {
	OX,PMX, OX_PP, Cycles_CX, CO_Ordinal_Encoding
}
