package utilsFlight;

public class TAsignacion {
	public double TLA;
	public double tel;
	public FlightType type;
	public int pos_gen;
	
	public TAsignacion(double TLA_ , FlightType type_) {
		// TODO Auto-generated constructor stub
		TLA = TLA_;
		type = type_;
	}
	
	public TAsignacion() {
	}

}
