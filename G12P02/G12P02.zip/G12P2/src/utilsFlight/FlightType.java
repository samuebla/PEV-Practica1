package utilsFlight;

/*
 * @author Jose Daniel y Samuel Bl�zquez
 */
public enum FlightType {
	W, G, P
}
